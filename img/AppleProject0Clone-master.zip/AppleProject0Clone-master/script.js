$(document).ready(function(){
    $('#search').click(function(){
        $('.menu-item').toggleClass('hide-item')
        $('.search-form').toggleClass('active')
    })
})